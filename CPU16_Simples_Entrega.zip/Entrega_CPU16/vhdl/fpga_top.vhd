library ieee;
use ieee.std_logic_1164.all;

entity fpga_top is
  generic (
    INIT_FILE      : string := "programas/01_operacoes.mif";
    CICLOS_ESTAVEIS : positive := 500000
  );
  port (
    CLOCK_50 : in  std_logic;
    KEY      : in  std_logic_vector(1 downto 0);
    SW       : in  std_logic_vector(17 downto 17);
    LEDG     : out std_logic_vector(8 downto 0);
    HEX0, HEX1, HEX2, HEX3, HEX4, HEX5, HEX6, HEX7 : out std_logic_vector(6 downto 0)
  );
end entity;

architecture rtl of fpga_top is
  signal reset_sync : std_logic_vector(1 downto 0) := "11";
  signal reset, passo, escreve : std_logic;
  signal endereco : std_logic_vector(11 downto 0);
  signal leitura, dado, pc, rdm, ula, display_alto : std_logic_vector(15 downto 0);
begin
  -- KEY0 esta ativo em zero. A liberacao do reset e sincronizada.
  process(CLOCK_50, KEY(0))
  begin
    if KEY(0) = '0' then
      reset_sync <= "11";
    elsif rising_edge(CLOCK_50) then
      reset_sync <= reset_sync(0) & '0';
    end if;
  end process;
  reset <= reset_sync(1);

  botao : entity work.debouncer
    generic map (CICLOS_ESTAVEIS => CICLOS_ESTAVEIS)
    port map (clk => CLOCK_50, reset => reset, botao_n => KEY(1), passo => passo);

  processador : entity work.cpu
    port map (
      clk => CLOCK_50, reset => reset, passo => passo,
      mem_leitura => leitura, mem_endereco => endereco, mem_dado => dado,
      mem_escreve => escreve, pc_display => pc, rdm_display => rdm,
      ula_display => ula, leds => LEDG
    );

  memoria : entity work.ram
    generic map (INIT_FILE => INIT_FILE)
    port map (clk => CLOCK_50, escreve => escreve, endereco => endereco,
              dado => dado, leitura => leitura);

  display_alto <= rdm when SW(17) = '0' else ula;

  h0 : entity work.hex7 port map (pc(3 downto 0), HEX0);
  h1 : entity work.hex7 port map (pc(7 downto 4), HEX1);
  h2 : entity work.hex7 port map (pc(11 downto 8), HEX2);
  h3 : entity work.hex7 port map (pc(15 downto 12), HEX3);
  h4 : entity work.hex7 port map (display_alto(3 downto 0), HEX4);
  h5 : entity work.hex7 port map (display_alto(7 downto 4), HEX5);
  h6 : entity work.hex7 port map (display_alto(11 downto 8), HEX6);
  h7 : entity work.hex7 port map (display_alto(15 downto 12), HEX7);
end architecture;
