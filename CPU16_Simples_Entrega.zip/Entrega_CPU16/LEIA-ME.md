# CPU de 16 bits

Abra `Especificacao_CPU16.pdf` para ver os diagramas, os resultados medidos nas ferramentas e o roteiro de bancada. O PDF tem campos para preencher a identificação do grupo e registrar o teste físico.

## Arquivos

| Arquivo ou pasta | Conteúdo |
|---|---|
| `vhdl/` | Cinco fontes VHDL do projeto. Comece por `cpu.vhd`. |
| `programas/` | Dois MIFs comentados linha a linha em assembly. |
| `cpu16.qpf` | Projeto do Quartus para a DE2-115, com `fpga_top` como entidade principal. |
| `fpga/` | Um arquivo de gravação SOF para cada MIF. |
| `simulacao/` | Testbench e comandos para reproduzir os testes no ModelSim Intel FPGA Edition. |

## Testar na placa

1. Confira se a placa é a **DE2-115** com **EP4CE115F29C7**. A pinagem usa JP7 em 2,5 V e JP6 em 3,3 V. Confira a configuração com o responsável pelo laboratório.
2. Ligue a placa e conecte o USB-Blaster. No Quartus Programmer, selecione **USB-Blaster** em **Hardware Setup** e **JTAG** como modo. Carregue `fpga/01_operacoes.sof`, marque **Program/Configure** e clique em **Start**.
3. Pressione e solte **KEY0** para começar do PC `0000`. Pressione e solte **KEY1** para avançar um estado por vez. Os LEDs verdes mostram a próxima etapa a executar.
4. No quinto aperto, **HEX3 a HEX0** mostram `0001`. Em **HEX7 a HEX4** aparece `520A` com **SW17 = 0** e `000A` com **SW17 = 1**.
5. Ao terminar o `LD`, confira PC `0009` e RDM `0007` antes de avançar. Para o segundo teste, grave `fpga/02_desvios.sof`. O PC volta duas vezes de `0004` para `0002` e o programa termina em laço no endereço `000B`.

Para alterar o código, abra `cpu16.qpf` no **Quartus Prime Lite** com suporte a **Cyclone IV E** e selecione **Processing → Start Compilation**. O novo SOF sai em `output_files/cpu16.sof`. O projeto começa com `programas/01_operacoes.mif`. Para selecionar outro MIF ao compilar, troque o caminho nas linhas `MIF_FILE` e `INIT_FILE` do arquivo `cpu16.qsf`. O reset zera a CPU. Para voltar ao conteúdo inicial da RAM após um `ST`, grave o SOF de novo.

Para repetir a simulação, abra o ModelSim Intel FPGA Edition na pasta que contém `cpu16.qpf` e digite `do simulacao/testar.do` na janela **Transcript**. O teste roda os dois MIFs e confere os registradores finais.

## Arguição

**Por que há duas etapas de busca?** A RAM é síncrona. Em BUSCA ela recebe o endereço do PC. Em CAPTURA o núcleo guarda a palavra lida em `instr` e no RDM.

**O que muda em `LD` e `ST`?** A ULA calcula `Rj + imediato` nos dois casos. No `ST`, MEMORIA escreve o valor de `Ri`. No `LD`, MEMORIA lê e GRAVA copia o dado para `Ri` e para o RDM.

**Como funciona o `BNE` que volta de `0004` para `0002`?** A ULA verifica se a diferença é zero. Enquanto `R1` difere de `R0`, o PC recebe `4 + (−2)`. Quando `R1` chega a zero, o PC recebe `4 + 1`.

**Por que segurar KEY1 só avança uma vez?** O debouncer espera cerca de 10 ms de nível estável e gera um pulso de um ciclo na transição para pressionado. A CPU só muda de estado com esse pulso ou com o reset.

**O que aparece em HEX7 a HEX4?** O RDM guarda a última instrução capturada ou o último dado obtido por `LD`. Com SW17 em 1 aparece o último resultado registrado da ULA.

Para a entrega, o enunciado pede o PDF preenchido, os cinco arquivos `.vhd` da pasta `vhdl/` e os dois programas `.mif` da pasta `programas/`. Um integrante faz o envio pelo Canvas.
