library ieee;
use ieee.std_logic_1164.all;

entity debouncer is
  generic (CICLOS_ESTAVEIS : positive := 500000);
  port (
    clk, reset, botao_n : in  std_logic;
    passo              : out std_logic
  );
end entity;

architecture rtl of debouncer is
  signal sync1, sync2, nivel_estavel : std_logic := '1';
  signal contador : natural range 0 to CICLOS_ESTAVEIS - 1 := 0;
begin
  process(clk)
  begin
    if rising_edge(clk) then
      passo <= '0';
      if reset = '1' then
        sync1        <= '1';
        sync2        <= '1';
        nivel_estavel <= '1';
        contador     <= 0;
      else
        -- Dois flip-flops sincronizam o botao ao clock da placa.
        sync1 <= botao_n;
        sync2 <= sync1;
        if sync2 = nivel_estavel then
          contador <= 0;
        elsif contador = CICLOS_ESTAVEIS - 1 then
          nivel_estavel <= sync2;
          contador     <= 0;
          if sync2 = '0' then
            passo <= '1';
          end if;
        else
          contador <= contador + 1;
        end if;
      end if;
    end if;
  end process;
end architecture;
