onerror {quit -code 1}
onbreak {quit -code 1}

if {![file isdirectory work]} {
    vlib work
}
vcom -2008 vhdl/cpu.vhd vhdl/ram.vhd vhdl/debouncer.vhd vhdl/hex7.vhd +    vhdl/fpga_top.vhd simulacao/tb_cpu16.vhd

foreach {teste esperados} {
    1 {0001 000A FFFD 0007 000D 0007 FFFF 0001}
    2 {0000 0000 0003 0000 0000 0000 0000 0000}
} {
    vsim -t 1ps -voptargs=+acc work.tb_cpu16 -gTESTE=$teste
    run 100 us
    if {![examine sim:/tb_cpu16/concluiu]} {
        error "O teste $teste nao concluiu"
    }
    set obtidos {}
    for {set i 0} {$i < 8} {incr i} {
        lappend obtidos [string toupper [examine -radix hexadecimal sim:/tb_cpu16/dut/processador/regs($i)]]
    }
    if {$obtidos ne $esperados} {
        error "Teste $teste: registradores R0 a R7 = $obtidos. Esperados: $esperados"
    }
    puts "PASS teste $teste: R0 a R7 = $obtidos"
    quit -sim
}
quit -code 0
