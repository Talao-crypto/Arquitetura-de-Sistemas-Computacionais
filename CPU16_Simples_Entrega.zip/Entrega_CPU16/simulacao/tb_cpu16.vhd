library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_cpu16 is
  generic (TESTE : positive := 1);
end entity;

architecture teste_placa of tb_cpu16 is
  subtype palavra is std_logic_vector(15 downto 0);
  subtype segmento is std_logic_vector(6 downto 0);
  type tabela_hex is array (0 to 15) of segmento;
  constant CODIGOS : tabela_hex := (
    "1000000", "1111001", "0100100", "0110000",
    "0011001", "0010010", "0000010", "1111000",
    "0000000", "0010000", "0001000", "0000011",
    "1000110", "0100001", "0000110", "0001110"
  );
  type classe_t is (OPERACAO, CARGA, ESCRITA, SALTO);

  function arquivo return string is
  begin
    if TESTE = 1 then
      return "programas/01_operacoes.mif";
    end if;
    return "programas/02_desvios.mif";
  end function;

  function digito(s : segmento) return std_logic_vector is
  begin
    for i in CODIGOS'range loop
      if s = CODIGOS(i) then
        return std_logic_vector(to_unsigned(i, 4));
      end if;
    end loop;
    return "XXXX";
  end function;

  signal clock_50 : std_logic := '0';
  signal key : std_logic_vector(1 downto 0) := "10";
  signal sw : std_logic_vector(17 downto 17) := "0";
  signal ledg : std_logic_vector(8 downto 0);
  signal h0, h1, h2, h3, h4, h5, h6, h7 : segmento;
  signal pc_display, display_alto : palavra;
  signal mudancas : natural := 0;
  signal concluiu : boolean := false;
begin
  clock_50 <= not clock_50 after 10 ns;
  dut : entity work.fpga_top
    generic map (INIT_FILE => arquivo, CICLOS_ESTAVEIS => 4)
    port map (clock_50, key, sw, ledg, h0, h1, h2, h3, h4, h5, h6, h7);

  pc_display   <= digito(h3) & digito(h2) & digito(h1) & digito(h0);
  display_alto <= digito(h7) & digito(h6) & digito(h5) & digito(h4);

  process(ledg)
  begin
    mudancas <= mudancas + 1;
  end process;

  process
    variable quantidade : natural := 0;

    procedure confere(led : natural; pc : palavra) is
    begin
      assert ledg = std_logic_vector(to_unsigned(2**led, ledg'length))
        report "LED incorreto no PC " & to_hstring(pc) severity failure;
      assert pc_display = pc
        report "PC esperado " & to_hstring(pc) & ", obtido " &
               to_hstring(pc_display) severity failure;
    end procedure;

    procedure confere_hex(switch : std_logic; esperado : palavra) is
    begin
      sw(17) <= switch;
      wait for 1 ns;
      assert display_alto = esperado
        report "HEX7..4 esperados " & to_hstring(esperado) & ", obtidos " &
               to_hstring(display_alto) severity failure;
    end procedure;

    procedure pressiona is
      variable antes : natural;
    begin
      antes := mudancas;
      key(1) <= '0';
      wait for 300 ns;
      key(1) <= '1';
      wait for 200 ns;
      assert mudancas = antes + 1
        report "KEY1 deve avancar uma vez por aperto" severity failure;
    end procedure;

    procedure executa(pc, instr, ula, proximo_pc : palavra;
                      classe : classe_t := OPERACAO;
                      dado_ld : palavra := x"0000") is
    begin
      confere(0, pc);
      pressiona;
      confere(1, pc);
      pressiona;
      confere(2, pc);
      confere_hex('0', instr);
      pressiona;
      confere(3, pc);
      pressiona;
      confere_hex('1', ula);

      if classe = CARGA or classe = ESCRITA then
        confere(4, pc);
        pressiona;
      end if;
      if classe = OPERACAO or classe = CARGA then
        confere(5, pc);
        pressiona;
      end if;

      confere(0, proximo_pc);
      if classe = CARGA then
        confere_hex('0', dado_ld);
        confere_hex('1', ula);
      end if;
      quantidade := quantidade + 1;
    end procedure;
  begin
    assert TESTE <= 2 report "Selecione TESTE 1 ou 2" severity failure;
    wait for 100 ns;
    key(0) <= '1';
    wait for 200 ns;
    confere(0, x"0000");
    confere_hex('0', x"0000");
    confere_hex('1', x"0000");

    -- Pulsos curtos simulam repiques no contato, antes do primeiro aperto.
    for i in 1 to 3 loop
      key(1) <= '0';
      wait for 20 ns;
      key(1) <= '1';
      wait for 20 ns;
    end loop;
    wait for 200 ns;
    confere(0, x"0000");
    confere_hex('0', x"0000");
    confere_hex('1', x"0000");

    if TESTE = 1 then
      executa(x"0000", x"520A", x"000A", x"0001");
      executa(x"0001", x"543D", x"FFFD", x"0002");
      executa(x"0002", x"0650", x"0007", x"0003");
      executa(x"0003", x"1850", x"000D", x"0004");
      executa(x"0004", x"2A50", x"0008", x"0005");
      executa(x"0005", x"3C50", x"FFFF", x"0006");
      executa(x"0006", x"4E88", x"0001", x"0007");
      executa(x"0007", x"763F", x"FFFF", x"0008", ESCRITA);
      executa(x"0008", x"6A3F", x"FFFF", x"0009", CARGA, x"0007");
      executa(x"0009", x"8AC2", x"0000", x"000B", SALTO);
      executa(x"000B", x"9282", x"FFF3", x"000D", SALTO);
      executa(x"000D", x"5001", x"0001", x"000E");
      executa(x"000E", x"A00E", x"0000", x"000E", SALTO);
    else
      executa(x"0000", x"5203", x"0003", x"0001");
      executa(x"0001", x"5400", x"0000", x"0002");
      for valor in 1 to 3 loop
        executa(x"0002", x"5481", std_logic_vector(to_unsigned(valor, 16)), x"0003");
        executa(x"0003", x"527F", std_logic_vector(to_unsigned(3-valor, 16)), x"0004");
        if valor < 3 then
          executa(x"0004", x"923E", std_logic_vector(to_signed(valor-3, 16)), x"0002", SALTO);
        else
          executa(x"0004", x"923E", x"0000", x"0005", SALTO);
        end if;
      end loop;
      executa(x"0005", x"8202", x"0000", x"0007", SALTO);
      executa(x"0007", x"9203", x"0000", x"0008", SALTO);
      executa(x"0008", x"8402", x"FFFD", x"0009", SALTO);
      executa(x"0009", x"A00B", x"0000", x"000B", SALTO);
      executa(x"000B", x"A00B", x"0000", x"000B", SALTO);
    end if;

    report "PASS " & arquivo & ": " & integer'image(quantidade) &
           " instrucoes, PC, LEDs, RDM, ULA e KEY1";
    concluiu <= true;
    wait;
  end process;
end architecture;
