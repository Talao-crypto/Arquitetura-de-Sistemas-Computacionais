library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity cpu is
  port (
    clk, reset, passo : in  std_logic;
    mem_leitura      : in  std_logic_vector(15 downto 0);
    mem_endereco     : out std_logic_vector(11 downto 0);
    mem_dado         : out std_logic_vector(15 downto 0);
    mem_escreve      : out std_logic;
    pc_display       : out std_logic_vector(15 downto 0);
    rdm_display      : out std_logic_vector(15 downto 0);
    ula_display      : out std_logic_vector(15 downto 0);
    leds             : out std_logic_vector(8 downto 0)
  );
end entity;

architecture rtl of cpu is
  subtype palavra is std_logic_vector(15 downto 0);
  type banco_reg is array (0 to 7) of palavra;
  type estado_t is (BUSCA, CAPTURA, DECODIFICA, EXECUTA, MEMORIA, GRAVA, INVALIDA);

  constant OP_ADD  : std_logic_vector(3 downto 0) := x"0";
  constant OP_SUB  : std_logic_vector(3 downto 0) := x"1";
  constant OP_AND  : std_logic_vector(3 downto 0) := x"2";
  constant OP_OR   : std_logic_vector(3 downto 0) := x"3";
  constant OP_SLT  : std_logic_vector(3 downto 0) := x"4";
  constant OP_ADDI : std_logic_vector(3 downto 0) := x"5";
  constant OP_LD   : std_logic_vector(3 downto 0) := x"6";
  constant OP_ST   : std_logic_vector(3 downto 0) := x"7";
  constant OP_BEQ  : std_logic_vector(3 downto 0) := x"8";
  constant OP_BNE  : std_logic_vector(3 downto 0) := x"9";
  constant OP_JMP  : std_logic_vector(3 downto 0) := x"A";

  signal estado : estado_t := BUSCA;
  signal regs : banco_reg := (others => (others => '0'));
  signal pc : unsigned(11 downto 0) := (others => '0');
  signal instr, rdm, a, b, saida_ula : palavra := (others => '0');
  signal opcode : std_logic_vector(3 downto 0);
  signal ri, rj, rk : natural range 0 to 7;
  signal imediato : signed(15 downto 0);
  signal entrada_b, resultado_ula : palavra;
  signal usa_endereco_ula : std_logic;
begin
  opcode   <= instr(15 downto 12);
  ri       <= to_integer(unsigned(instr(11 downto 9)));
  rj       <= to_integer(unsigned(instr(8 downto 6)));
  rk       <= to_integer(unsigned(instr(5 downto 3)));
  imediato <= resize(signed(instr(5 downto 0)), 16);

  -- O segundo operando da ULA vem de um registrador ou do imediato.
  entrada_b <= std_logic_vector(imediato)
    when opcode = OP_ADDI or opcode = OP_LD or opcode = OP_ST else b;

  process(a, entrada_b, opcode)
  begin
    resultado_ula <= (others => '0');
    case opcode is
      when OP_ADD | OP_ADDI | OP_LD | OP_ST =>
        resultado_ula <= std_logic_vector(unsigned(a) + unsigned(entrada_b));
      when OP_SUB | OP_BEQ | OP_BNE =>
        resultado_ula <= std_logic_vector(unsigned(a) - unsigned(entrada_b));
      when OP_AND =>
        resultado_ula <= a and entrada_b;
      when OP_OR =>
        resultado_ula <= a or entrada_b;
      when OP_SLT =>
        if signed(a) < signed(entrada_b) then
          resultado_ula <= x"0001";
        end if;
      when others =>
        null;
    end case;
  end process;

  -- Mantem o endereco do LD ate a captura do dado no estado GRAVA.
  usa_endereco_ula <= '1' when estado = MEMORIA or
    (estado = GRAVA and opcode = OP_LD) else '0';
  mem_endereco <= saida_ula(11 downto 0) when usa_endereco_ula = '1'
    else std_logic_vector(pc);
  mem_dado <= b;
  mem_escreve <= '1' when estado = MEMORIA and opcode = OP_ST
    and passo = '1' and reset = '0' else '0';

  pc_display  <= x"0" & std_logic_vector(pc);
  rdm_display <= rdm;
  ula_display <= saida_ula;

  with estado select leds <=
    "000000001" when BUSCA,
    "000000010" when CAPTURA,
    "000000100" when DECODIFICA,
    "000001000" when EXECUTA,
    "000010000" when MEMORIA,
    "000100000" when GRAVA,
    "100000000" when INVALIDA;

  process(clk)
  begin
    if rising_edge(clk) then
      if reset = '1' then
        estado    <= BUSCA;
        regs      <= (others => (others => '0'));
        pc        <= (others => '0');
        instr     <= (others => '0');
        rdm       <= (others => '0');
        a         <= (others => '0');
        b         <= (others => '0');
        saida_ula <= (others => '0');
      elsif passo = '1' then
        case estado is
          when BUSCA =>
            -- A RAM le o endereco do PC nesta borda de clock.
            estado <= CAPTURA;

          when CAPTURA =>
            instr  <= mem_leitura;
            rdm    <= mem_leitura;
            estado <= DECODIFICA;

          when DECODIFICA =>
            a <= regs(rj);
            if opcode = OP_ST or opcode = OP_BEQ or opcode = OP_BNE then
              b <= regs(ri);
            else
              b <= regs(rk);
            end if;
            estado <= EXECUTA;

          when EXECUTA =>
            saida_ula <= resultado_ula;
            case opcode is
              when OP_ADD | OP_SUB | OP_AND | OP_OR | OP_SLT | OP_ADDI =>
                estado <= GRAVA;
              when OP_LD | OP_ST =>
                estado <= MEMORIA;
              when OP_BEQ | OP_BNE =>
                -- O PC ainda aponta para a propria instrucao de desvio.
                if (opcode = OP_BEQ and resultado_ula = x"0000") or
                   (opcode = OP_BNE and resultado_ula /= x"0000") then
                  pc <= pc + unsigned(imediato(11 downto 0));
                else
                  pc <= pc + 1;
                end if;
                estado <= BUSCA;
              when OP_JMP =>
                pc     <= unsigned(instr(11 downto 0));
                estado <= BUSCA;
              when others =>
                estado <= INVALIDA;
            end case;

          when MEMORIA =>
            if opcode = OP_LD then
              -- A RAM le o endereco calculado na ULA nesta borda.
              estado <= GRAVA;
            else
              -- O ST escreve na RAM pela porta mem_escreve.
              pc     <= pc + 1;
              estado <= BUSCA;
            end if;

          when GRAVA =>
            if opcode = OP_LD then
              rdm      <= mem_leitura;
              regs(ri) <= mem_leitura;
            else
              regs(ri) <= saida_ula;
            end if;
            pc     <= pc + 1;
            estado <= BUSCA;

          when INVALIDA =>
            null;
        end case;
      end if;
    end if;
  end process;
end architecture;
